#ifndef MATH_H
#define MATH_H

extern long rand_seed;

int math_min(int x, int y);

int math_max(int x, int y);

int math_clamp(int num, int x, int y);

int math_random(int x, int y);

#endif