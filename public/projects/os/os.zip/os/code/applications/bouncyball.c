#include "../../include/types.h"

#include "../kernel.h"
#include "../math.h"
#include "../graphics.h"

#include "bouncyball.h"

void applications_bouncyball_OnKeyDown(unsigned char scancode);
void applications_bouncyball_OnKeyUp(unsigned char scancode);
void applications_bouncyball_clean();
void applications_bouncyball_update();

float balls[10][5];

void applications_bouncyball_init() {
    graphics_clear_screen();
    application_Clean = (void*)applications_bouncyball_clean;
    application_Update = (void*)applications_bouncyball_update;
    application_OnKeyDown = (void*)applications_bouncyball_OnKeyDown;
    application_OnKeyUp = (void*)applications_bouncyball_OnKeyUp;

    for (int i = 0; i < 10; i++) {
        balls[i][0] = math_random(15, 305);
        balls[i][1] = math_random(15, 185);
        balls[i][2] = math_random(1, 2);
        balls[i][3] = math_random(1, 2);
        balls[i][4] = math_random(1, 255);
    }
}

void applications_bouncyball_OnKeyDown(unsigned char scancode) {
    
}

void applications_bouncyball_OnKeyUp(unsigned char scancode) {

}

void applications_bouncyball_clean() {
    graphics_clear_screen();
}

void applications_bouncyball_update() {
    graphics_clear_screen();

    for (int i = 0; i < 10; i++) {
        if((balls[i][0] + 5) + balls[i][2] > 320 - 5 || (balls[i][0] + 5) + balls[i][2] < 5) {
            balls[i][2] = -balls[i][2];
        }
        if((balls[i][1] + 5) + balls[i][3] < 5 || (balls[i][1] + 5) + balls[i][3] > 200 - 5) {
            balls[i][3] = -balls[i][3];
        }

        balls[i][0] = (balls[i][0] + balls[i][2]);
        balls[i][1] = (balls[i][1] + balls[i][3]);

        //graphics_rect(balls[i][0], balls[i][1], 10, 10, balls[i][4]);
        graphics_circle(balls[i][0], balls[i][1], 5, balls[i][4]);
    }
}