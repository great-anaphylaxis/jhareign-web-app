#ifndef APP_BOUNCYBALL_H
#define APP_BOUNCYBALL_H

void applications_bouncyball_init();

#endif