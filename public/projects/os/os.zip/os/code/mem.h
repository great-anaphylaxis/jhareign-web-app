#ifndef MEM_H
#define MEM_H

extern int* mem_head;
extern int* mem_start;
extern int* mem_limit;

void* memset(void* dest, unsigned char val, int count);

void memcp(unsigned char* source, unsigned char* dest, int count);

void* malloc();

void* mfree(void* ptr);

#endif