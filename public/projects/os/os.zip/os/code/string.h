#ifndef STRING_H
#define STRING_H

extern char string_buffer[512];

char* string_itoa(int value, char * str, int base);

int string_atoi(char *str);

char* string_concat(char *str1, char *str2);

int string_compare(char *str1, char *str2);

#endif