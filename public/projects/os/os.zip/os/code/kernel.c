#include "../include/types.h"

#include "kernel.h"
#include "math.h"
#include "string.h"
#include "graphics.h"
#include "idt.h"
#include "isrs.h"
#include "irq.h"
#include "mem.h"

#include "applications/bouncyball.h"

volatile int ticks = 0;
short isShift = 0;

char shell_contents[25][40] = {0};
int horizontal_head = 0;
int vertical_head = 0;
char kernel_color = 1;
int isKernelActive = 1;

void (*application_OnKeyDown)(unsigned char scancode) = 0;
void (*application_OnKeyUp)(unsigned char scancode) = 0;
void (*application_Clean)() = 0;
void (*application_Update)() = 0;

char music_isLoop = 0;
int music_tempo = 20;
int note_head = 0;
char *music_piece = 0;


char tetris_theme[] = {4,5,-1,11,4,0,5,2,5,-1,0,5,11,4,9,4,-1,-1,0,5,4,5,-1,2,5,0,5,11,4,-1,11,4,0,5,2,5,-1,4,5,-1,0,5,-1,9,4,-1,9,4,9,4,11,4,0,5,2,5,-1,-1,5,5,9,5,-1,7,5,5,5,4,5,-1,-1,0,5,4,5,-1,2,5,0,5,11,4,-1,11,4,0,5,2,5,-1,4,5,-1,0,5,-1,9,4,-1,9,4,-1,-1,-1, -2};
char messy_tetris_theme[] = {4,5,4,4,11,4,0,5,2,5,2,4,0,5,11,4,9,4,9,2,9,3,0,5,4,5,4,4,2,5,0,5,11,4,11,3,11,4,0,5,2,5,2,4,4,5,4,4,0,5,0,4,9,4,9,1,9,2,9,3,11,3,0,4,2,5,2,3,2,4,5,5,9,5,9,4,7,5,5,5,4,5,4,3,4,4,0,5,4,5,4,4,2,5,0,5,11,4,11,3,11,4,0,5,2,5,2,4,4,5,4,4,0,5,0,4,9,4,9,2,9,3,-1,-1,-1, -2};
char raush_e[] = {4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,-1,0,5,-1,-1,-1,2,5,2,4,2,5,2,4,2,5,0,5,11,4,2,5,0,5,0,4,0,5,0,4,0,5,11,4,9,4,0,5,11,4,11,3,11,4,11,3,6,4,-1,11,4,-1,8,4,-1,-1,-1,4,3,-1,-1,-1,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,0,5,4,5,-1,9,5,-1,0,6,-1,-1,-1,2,6,0,6,11,5,2,6,0,6,11,5,9,5,0,6,11,5,9,5,8,5,11,5,9,5,4,5,0,5,9,4,5,5,4,5,2,5,0,5,11,4,9,4,8,4,11,4,9,4,-1,-1,-1,4,3,-1,-1,-1,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,-1,0,5,-1,-1,-1,2,5,2,4,2,5,2,4,2,5,0,5,11,4,2,5,0,5,0,4,0,5,0,4,0,5,11,4,9,4,0,5,11,4,11,3,11,4,11,3,6,4,-1,11,4,-1,8,4,-1,-1,-1,4,3,-1,-1,-1,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,0,5,4,5,-1,9,5,-1,0,6,-1,-1,-1,2,6,0,6,11,5,2,6,0,6,11,5,9,5,0,6,11,5,9,5,8,5,11,5,9,5,4,5,0,5,9,4,5,5,4,5,2,5,0,5,11,4,9,4,8,4,11,4,9,4,-1,-1,-1,4,3,-1,-1,-1,2,5,-1,-1,1,5,2,5,-1,4,5,-1,5,5,-1,4,5,-1,2,5,-1,5,5,-1,4,5,-1,-1,2,5,0,5,-1,2,5,-1,4,5,-1,-1,-1,-1,0,5,-1,11,4,-1,-1,9,4,11,4,-1,0,5,-1,2,5,-1,0,5,-1,11,4,-1,2,5,-1,0,5,-1,11,4,-1,9,4,-1,0,5,-1,4,5,-1,0,5,-1,9,4,-1,0,5,-1,2,5,-1,-1,1,5,2,5,-1,4,5,-1,5,5,-1,4,5,-1,2,5,-1,5,5,-1,4,5,-1,-1,2,5,0,5,-1,2,5,-1,4,5,-1,-1,-1,9,5,-1,-1,-1,-1,-1,2,5,-1,-1,5,5,-1,4,5,-1,0,5,-1,2,5,-1,11,4,-1,9,4,-1,-1,-1,-1,4,4,-1,9,4,-1,-1,-1,4,3,-1, -2};
char rush_e[] = {4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,-1,0,5,-1,-1,-1,2,5,2,4,2,5,2,4,2,5,0,5,11,4,2,5,0,5,0,4,0,5,0,4,0,5,11,4,9,4,0,5,11,4,11,3,11,4,11,3,6,4,-1,11,4,-1,8,4,-1,-1,-1,4,3,-1,-1,-1,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,0,5,4,5,-1,9,5,-1,0,6,-1,-1,-1,2,6,0,6,11,5,2,6,0,6,11,5,9,5,0,6,11,5,9,5,8,5,11,5,9,5,4,5,0,5,9,4,5,5,4,5,2,5,0,5,11,4,9,4,8,4,11,4,9,4,-1,-1,-1,4,3,-1,-1,-1,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,-1,0,5,-1,-1,-1,2,5,2,4,2,5,2,4,2,5,0,5,11,4,2,5,0,5,0,4,0,5,0,4,0,5,11,4,9,4,0,5,11,4,11,3,11,4,11,3,6,4,-1,11,4,-1,8,4,-1,-1,-1,4,3,-1,-1,-1,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,4,3,4,4,5,4,4,4,3,4,4,4,-1,9,4,0,5,4,5,-1,9,5,-1,0,6,-1,-1,-1,2,6,0,6,11,5,2,6,0,6,11,5,9,5,0,6,11,5,9,5,8,5,11,5,9,5,4,5,0,5,9,4,5,5,4,5,2,5,0,5,11,4,9,4,8,4,11,4,9,4,-1,-1,-1,4,3,-1,-1,-3,11,2,5,-1,-1,1,5,2,5,-1,4,5,-1,5,5,-1,4,5,-1,2,5,-1,5,5,-1,4,5,-1,-1,2,5,0,5,-1,2,5,-1,4,5,-1,-1,-1,-1,0,5,-1,11,4,-1,-1,9,4,11,4,-1,0,5,-1,2,5,-1,0,5,-1,11,4,-1,2,5,-1,0,5,-1,11,4,-1,9,4,-1,0,5,-1,4,5,-1,0,5,-1,9,4,-1,0,5,-1,2,5,-1,-1,1,5,2,5,-1,4,5,-1,5,5,-1,4,5,-1,2,5,-1,5,5,-1,4,5,-1,-1,2,5,0,5,-1,2,5,-1,4,5,-1,-1,-1,9,5,-1,-1,-1,-1,-1,2,5,-1,-1,5,5,-1,4,5,-1,0,5,-1,2,5,-1,11,4,-1,9,4,-1,-1,-1,-1,4,4,-1,9,4,-1,-1,-1,4,3,-3,14, -2};
unsigned char kbdus_unshift[128] = {
    0,  0, '1', '2', '3', '4', '5', '6', '7', '8',	/* 9 */
  '9', '0', '-', '=', 8,	/* Backspace */
  0,			/* Tab */
  'q', 'w', 'e', 'r',	/* 19 */
  't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',	/* Enter key */
    0,			/* 29   - Control */
  'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',	/* 39 */
 '\'', '`',   0,		/* Left shift */
 '\\', 'z', 'x', 'c', 'v', 'b', 'n',			/* 49 */
  'm', ',', '.', '/',   0,				/* Right shift */
  '*',
    0,	/* Alt */
  ' ',	/* Space bar */
    0,	/* Caps lock */
    0,	/* 59 - F1 key ... > */
    0,   0,   0,   0,   0,   0,   0,   0,
    0,	/* < ... F10 */
    0,	/* 69 - Num lock*/
    0,	/* Scroll Lock */
    0,	/* Home key */
    0,	/* Up Arrow */
    0,	/* Page Up */
  '-',
    0,	/* Left Arrow */
    0,
    0,	/* Right Arrow */
  '+',
    0,	/* 79 - End key*/
    0,	/* Down Arrow */
    0,	/* Page Down */
    0,	/* Insert Key */
    0,	/* Delete Key */
    0,   0,   0,
    0,	/* F11 Key */
    24,	/* F12 Key */
    0,	/* All other keys are undefined */
};

unsigned char kbdus_shift[128] = {
    0,  0, '!', '@', '#', '$', '%', '^', '&', '*',	/* 9 */
  '(', ')', '_', '+', 8,	/* Backspace */
  0,			/* Tab */
  'Q', 'W', 'E', 'R',	/* 19 */
  'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',	/* Enter key */
    0,			/* 29   - Control */
  'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':',	/* 39 */
 '"', '~',   0,		/* Left shift */
 '|', 'Z', 'X', 'C', 'V', 'B', 'N',			/* 49 */
  'M', '<', '>', '?',   0,				/* Right shift */
  '*',
    0,	/* Alt */
  ' ',	/* Space bar */
    0,	/* Caps lock */
    0,	/* 59 - F1 key ... > */
    0,   0,   0,   0,   0,   0,   0,   0,
    0,	/* < ... F10 */
    0,	/* 69 - Num lock*/
    0,	/* Scroll Lock */
    0,	/* Home key */
    0,	/* Up Arrow */
    0,	/* Page Up */
  '-',
    0,	/* Left Arrow */
    0,
    0,	/* Right Arrow */
  '+',
    0,	/* 79 - End key*/
    0,	/* Down Arrow */
    0,	/* Page Down */
    0,	/* Insert Key */
    0,	/* Delete Key */
    0,   0,   0,
    0,	/* F11 Key */
    24,	/* F12 Key */
    0,	/* All other keys are undefined */
};

////////////////////////////////////////////////////

void kernel_OnKeyDown(char keycode) {
    graphics_rect(horizontal_head * 8, vertical_head * 8, 8, 8, 0);

    if (keycode == 8) {
        if (horizontal_head != 0) {
            horizontal_head -= 1;
            shell_contents[vertical_head][horizontal_head] = 0;
        }
        graphics_rect(0, vertical_head * 8, 320, 8, 0);
        graphics_print_string(shell_contents[vertical_head], 0, vertical_head * 8, kernel_color, 40, 1);

        graphics_rect((horizontal_head * 8) + 1, (vertical_head * 8) + 7, 6, 1, kernel_color);
    }
    else if (keycode == '\n') {
        vertical_head += 1;
        horizontal_head = 0;

        if (vertical_head == 25) {
            graphics_clear_screen();
            vertical_head -= 1;

            for (int i = 0; i < 24; i++) {
                for (int j = 0; j < 40; j++) {
                    shell_contents[i][j] = shell_contents[i + 1][j];
                }

                graphics_print_string(shell_contents[i], 0, i * 8, kernel_color, 40, 1);
            }

            for (int i = 0; i < 40; i++) {
                shell_contents[vertical_head][i] = 0;
            }
        }
        graphics_rect((horizontal_head * 8) + 1, (vertical_head * 8) + 7, 6, 1, kernel_color);
        kernel_runCommand(shell_contents[vertical_head - 1]);
    }
    else if (keycode != 0) {
        shell_contents[vertical_head][horizontal_head] = keycode;

        horizontal_head++;
        graphics_print_string(shell_contents[vertical_head], 0, vertical_head * 8, kernel_color, 40, 1);

        if (horizontal_head == 40) {
            horizontal_head = 0;
            vertical_head += 1;
        }

        if (vertical_head == 25) {
            graphics_clear_screen();
            vertical_head -= 1;

            for (int i = 0; i < 24; i++) {
                for (int j = 0; j < 40; j++) {
                    shell_contents[i][j] = shell_contents[i + 1][j];
                }

                graphics_print_string(shell_contents[i], 0, i * 8, kernel_color, 40, 1);
            }

            for (int i = 0; i < 40; i++) {
                shell_contents[vertical_head][i] = 0;
            }
        }

        graphics_rect((horizontal_head * 8) + 1, (vertical_head * 8) + 7, 6, 1, kernel_color);
    }
    else {
        graphics_rect((horizontal_head * 8) + 1, (vertical_head * 8) + 7, 6, 1, kernel_color);
    }
}

void kernel_OnKeyUp(char keycode) {

}

void kernel_response(char *str) {
    graphics_rect(horizontal_head * 8, vertical_head * 8, 8, 8, 0);
    
    while (*str != 0) {
        if (*str == '\n') {
            vertical_head += 1;
            horizontal_head = 0;

            if (vertical_head == 25) {
                graphics_clear_screen();
                vertical_head -= 1;

                for (int i = 0; i < 24; i++) {
                    for (int j = 0; j < 40; j++) {
                        shell_contents[i][j] = shell_contents[i + 1][j];
                    }

                    graphics_print_string(shell_contents[i], 0, i * 8, kernel_color, 40, 1);
                }

                for (int i = 0; i < 40; i++) {
                    shell_contents[vertical_head][i] = 0;
                }
            }
        }

        else {
            shell_contents[vertical_head][horizontal_head] = *str;

            horizontal_head += 1;
            graphics_print_string(shell_contents[vertical_head], 0, vertical_head * 8, kernel_color, 40, 1);

            if (horizontal_head == 40) {
                horizontal_head = 0;
                vertical_head += 1;
            }

            if (vertical_head == 25) {
                graphics_clear_screen();
                vertical_head -= 1;

                for (int i = 0; i < 24; i++) {
                    for (int j = 0; j < 40; j++) {
                        shell_contents[i][j] = shell_contents[i + 1][j];
                    }

                    graphics_print_string(shell_contents[i], 0, i * 8, kernel_color, 40, 1);
                }

                for (int i = 0; i < 40; i++) {
                    shell_contents[vertical_head][i] = 0;
                }
            }
        }

        str += 1;
    }

    vertical_head += 1;
    horizontal_head = 0;
    if (vertical_head == 25) {
        graphics_clear_screen();
        vertical_head -= 1;

        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 40; j++) {
                shell_contents[i][j] = shell_contents[i + 1][j];
            }

            graphics_print_string(shell_contents[i], 0, i * 8, kernel_color, 40, 1);
        }

        for (int i = 0; i < 40; i++) {
            shell_contents[vertical_head][i] = 0;
        }
    }

    graphics_rect((horizontal_head * 8) + 1, (vertical_head * 8) + 7, 6, 1, kernel_color);
}

void kernel_runCommand(char *str) {
    char parsed_command[4][40] = {0};

    int current_stage = 0;
    int i = 0;
    while (*str != 0) {
        if (*str == ' ') {
            current_stage += 1;
            i = -1;

            if (current_stage > 3) {
                break;
            }
        }
        else {
            parsed_command[current_stage][i] = *str;
        }

        i += 1;
        str += 1;
    }

    if (string_compare(parsed_command[0], "color") == 1) {
        kernel_commands_color(parsed_command);
    }

    else if (string_compare(parsed_command[0], "run") == 1) {
        kernel_commands_run(parsed_command);
    }

    else if (string_compare(parsed_command[0], "audio") == 1) {
        kernel_commands_audio(parsed_command);
    }

    else if (string_compare(parsed_command[0], "help") == 1) {
        kernel_command_help(parsed_command);
    }

    else {
        kernel_response(string_concat(string_concat("The command '", parsed_command[0]), "' have not been found"));
    }
}

void kernel_exitApplication() {
    if (application_Clean) {
        application_Clean();
    }
    application_Clean = 0;

    for (int i = 0; i < 24; i++) {
        graphics_print_string(shell_contents[i], 0, i * 8, kernel_color, 40, 1);
    }
    graphics_rect((horizontal_head * 8) + 1, (vertical_head * 8) + 7, 6, 1, kernel_color);

    application_OnKeyUp = 0;
    application_OnKeyDown = 0;

    isKernelActive = 1;
}

void kernel_commands_color(char params[4][40]) {
    if (string_compare(params[1], "") == -1) {
        for (int i = 0; i < 40; i++) {
            if (params[1][i] == 0) {
                break;
            }
            else {
                params[1][i] = params[1][i];
            }
        }

        kernel_color = (char) string_atoi(params[1]);

        for (int i = 0; i < 25; i++) {
            graphics_print_string(shell_contents[i], 0, i * 8, kernel_color, 40, 1);
        }
    }
}

void kernel_commands_run(char params[4][40]) {
    if (string_compare(params[1], "bouncyball") == 1) {
        isKernelActive = 0;
        applications_bouncyball_init();
    }

    else {
        kernel_response(string_concat(string_concat("The application '", params[1]), "' have not been found"));
    }
}

void kernel_commands_audio(char params[4][40]) {
    if (string_compare(params[1], "messy_tetris_theme") == 1) {
        music_piece = 0;
        note_head = 0;
        music_isLoop = 0;

        music_piece = messy_tetris_theme;
        music_tempo = 20;

        if (string_compare(params[2], "loop") == 1) {
            music_isLoop = 1;
        }

        else if (string_compare(params[2], "noloop") == 1) {
            music_isLoop = 0;
        }

        else if (string_compare(params[2], "") != 1) {
            kernel_response(string_concat(params[2], "?"));
        }

        if (string_compare(params[3], "0") != 1 && string_compare(params[3], "") != 1) {
            int l_head = 0;
            int l_num = string_atoi(params[3]);

            if (l_num > 0) {
                while (1) {
                    if (music_piece[l_head] >= -0) {
                        music_piece[l_head + 1] = (char)(music_piece[l_head + 1] + ((music_piece[l_head] + l_num) / 12));
                        music_piece[l_head] = (char) (music_piece[l_head] + l_num) % 12;
                        l_head += 2;
                    }

                    else if (music_piece[l_head] == -1) {
                        l_head += 1;
                    }

                    else if (music_piece[l_head] == -2) {
                        break;
                    }

                    else if (music_piece[l_head] == -3) {
                        l_head += 2;
                    }
                }
            }

            else if (l_num < 0) {
                l_num *= -1;

                while (1) {
                    if (music_piece[l_head] >= -0) {
                        int i = 0;
                        int overflow = 0;
                        for (i = 0; i < l_num; i++) {
                            music_piece[l_head] -= 1;
                            if (music_piece[l_head] == -1) {
                                music_piece[l_head] = 11;
                                overflow++;
                            }
                        }
                        music_piece[l_head + 1] -= overflow;
                        l_head += 2;
                    }

                    else if (music_piece[l_head] == -1) {
                        l_head += 1;
                    }

                    else if (music_piece[l_head] == -2) {
                        break;
                    }

                    else if (music_piece[l_head] == -3) {
                        l_head += 2;
                    }
                }
            }
        }
    }

    else if (string_compare(params[1], "tetris_theme") == 1) {
        music_piece = 0;
        note_head = 0;
        music_isLoop = 0;

        music_piece = tetris_theme;
        music_tempo = 20;

        if (string_compare(params[2], "loop") == 1) {
            music_isLoop = 1;
        }

        else if (string_compare(params[2], "noloop") == 1) {
            music_isLoop = 0;
        }

        else if (string_compare(params[2], "") != 1) {
            kernel_response(string_concat(params[2], "?"));
        }

        if (string_compare(params[3], "0") != 1 && string_compare(params[3], "") != 1) {
            int l_head = 0;
            int l_num = string_atoi(params[3]);

            if (l_num > 0) {
                while (1) {
                    if (music_piece[l_head] >= -0) {
                        music_piece[l_head + 1] = (char)(music_piece[l_head + 1] + ((music_piece[l_head] + l_num) / 12));
                        music_piece[l_head] = (char) (music_piece[l_head] + l_num) % 12;
                        l_head += 2;
                    }

                    else if (music_piece[l_head] == -1) {
                        l_head += 1;
                    }

                    else if (music_piece[l_head] == -2) {
                        break;
                    }

                    else if (music_piece[l_head] == -3) {
                        l_head += 2;
                    }
                }
            }

            else if (l_num < 0) {
                l_num *= -1;

                while (1) {
                    if (music_piece[l_head] >= -0) {
                        int i = 0;
                        int overflow = 0;
                        for (i = 0; i < l_num; i++) {
                            music_piece[l_head] -= 1;
                            if (music_piece[l_head] == -1) {
                                music_piece[l_head] = 11;
                                overflow++;
                            }
                        }
                        music_piece[l_head + 1] -= overflow;
                        l_head += 2;
                    }

                    else if (music_piece[l_head] == -1) {
                        l_head += 1;
                    }

                    else if (music_piece[l_head] == -2) {
                        break;
                    }

                    else if (music_piece[l_head] == -3) {
                        l_head += 2;
                    }
                }
            }
        }
    }

    else if (string_compare(params[1], "rushE") == 1) {
        music_piece = 0;
        note_head = 0;
        music_isLoop = 0;

        music_piece = rush_e;
        music_tempo = 14;

        if (string_compare(params[2], "loop") == 1) {
            music_isLoop = 1;
        }

        else if (string_compare(params[2], "noloop") == 1) {
            music_isLoop = 0;
        }

        else if (string_compare(params[2], "") != 1) {
            kernel_response(string_concat(params[2], "?"));
        }

        if (string_compare(params[3], "0") != 1 && string_compare(params[3], "") != 1) {
            int l_head = 0;
            int l_num = string_atoi(params[3]);

            if (l_num > 0) {
                while (1) {
                    if (music_piece[l_head] >= -0) {
                        music_piece[l_head + 1] = (char)(music_piece[l_head + 1] + ((music_piece[l_head] + l_num) / 12));
                        music_piece[l_head] = (char) (music_piece[l_head] + l_num) % 12;
                        l_head += 2;
                    }

                    else if (music_piece[l_head] == -1) {
                        l_head += 1;
                    }

                    else if (music_piece[l_head] == -2) {
                        break;
                    }

                    else if (music_piece[l_head] == -3) {
                        l_head += 2;
                    }
                }
            }

            else if (l_num < 0) {
                l_num *= -1;

                while (1) {
                    if (music_piece[l_head] >= -0) {
                        int i = 0;
                        int overflow = 0;
                        for (i = 0; i < l_num; i++) {
                            music_piece[l_head] -= 1;
                            if (music_piece[l_head] == -1) {
                                music_piece[l_head] = 11;
                                overflow++;
                            }
                        }
                        music_piece[l_head + 1] -= overflow;
                        l_head += 2;
                    }

                    else if (music_piece[l_head] == -1) {
                        l_head += 1;
                    }

                    else if (music_piece[l_head] == -2) {
                        break;
                    }

                    else if (music_piece[l_head] == -3) {
                        l_head += 2;
                    }
                }
            }
        }
    }

    else if (string_compare(params[1], "stop") == 1) {
        music_piece = 0;
        note_head = 0;

        stop_sound();
    }

    else {
        kernel_response(string_concat(string_concat("The music piece '", params[1]), "' have not been found"));
    }
}

void kernel_command_help(char params[4][40]) {
    kernel_response("color <color>\nchanges the color\n\nrun <application>\nruns applications\n\naudio <music> <loop> <key>\nplays the specified music\n");
}

////////////////////////////////////////////////////

void keyboard_handler(struct regs *r) {
    unsigned char scancode;
    unsigned char b_scancode;
    char chosen_key;

    scancode = inb(0x60);
    b_scancode = scancode;
    
    if (b_scancode & 0x80) {
        if (scancode == 0xaa || scancode == 0xb6) {
            isShift = 0;
        }

        if (isShift == 0) {
            chosen_key = kbdus_unshift[scancode & 128];
        }
        
        else if (isShift == 1) {
            chosen_key = kbdus_shift[scancode & 128];
        }

        if (isKernelActive == 1) {
            kernel_OnKeyUp(chosen_key);
        }

        else if (isKernelActive == 0) {
            if (application_OnKeyUp) {
                application_OnKeyUp(scancode);
            }
        }
    }
    else {
        if (kbdus_unshift[scancode] == 24) {
            kernel_exitApplication();
            return;
        }

        if (scancode == 42 || scancode == 54) {
            isShift = 1;
        }

        if (isShift == 0) {
            chosen_key = kbdus_unshift[scancode];
        }
        
        else if (isShift == 1) {
            chosen_key = kbdus_shift[scancode];
        }

        if (isKernelActive == 1) {
            kernel_OnKeyDown(chosen_key);
        }

        else if (isKernelActive == 0) {
            if (application_OnKeyDown) {
                application_OnKeyDown(scancode);
            }
        }
    }
}

void timer_handler(struct regs *r) {
    ticks += 1;

    if (ticks > 100000000) {
        ticks = 0;
    }

    rand_seed = (rand_seed + 1);

    if (isKernelActive == 0) {
        if (ticks % 1 == 0) {
            if (application_Update) {
                application_Update();
            }
        }
    }

    if (ticks % music_tempo == 0) {
        if (music_piece != 0) {
            if (music_piece[note_head] == -3) {
                music_tempo = music_piece[note_head + 1];
                string_itoa(music_tempo, string_buffer, 10);
                note_head += 2;
            }

            else if (music_piece[note_head] > -2) {
                if (music_piece[note_head] >= -0) {
                    play_sound_asNotes(music_piece[note_head], music_piece[note_head + 1]);
                    note_head += 2;
                }

                else if (music_piece[note_head] == -1) {
                    note_head += 1;
                }
            }
            else if (music_piece[note_head] == -2) {
                if (music_isLoop == 1) {
                    note_head = 0;
                }
                else if (music_isLoop == 0) {
                    music_piece = 0;
                    note_head = 0;

                    stop_sound();
                }
            }
        }
    }
}

void timer_phase(int hz) {
    int divisor = 1193180 / hz;              /* Calculate our divisor */
    outb(0x43, 0x36);                        /* Set our command byte 0x36 */
    outb(0x40, divisor & 0xFF);              /* Set low byte of divisor */
    outb(0x40, (divisor >> 8) & 0xFF);       /* Set high byte of divisor */
}

void play_sound(uint32_t nFrequence) {
    uint32_t Div;
    uint8_t tmp;

    //Set the PIT to the desired frequency
    Div = 1193180 / nFrequence;
    outb(0x43, 0xb6);
    outb(0x42, (uint8_t) (Div) );
    outb(0x42, (uint8_t) (Div >> 8));

    //And play the sound using the PC speaker
    tmp = inb(0x61);
    if (tmp != (tmp | 3)) {
        outb(0x61, tmp | 3);
    }
}

void play_sound_asNotes(char note, char pitch) {
    char step_table[8][12] = {
        {-45, -44, -43, -42, -41, -40, -39, -38, -37, -36, -35, -34},
        {-33, -32, -31, -30, -29, -28, -27, -26, -25, -24, -23, -22},
        {-21, -20, -19, -18, -17, -16, -15, -14, -13, -12, -11, -10},
        {-9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2},
        {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
        {15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26},
        {27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38},
        {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50}
    };

    char chosen_step = step_table[pitch][note];
    float frequency = 440;

    if (chosen_step < 0) {
        chosen_step *= -1;

        for (int i = 0; i < chosen_step; i++) {
            frequency /= 1.059;
        }
    }

    else if (chosen_step > 0) {
        for (int i = 0; i < chosen_step; i++) {
            frequency *= 1.059;
        }
    }

    play_sound(frequency);

}

void stop_sound() {
    uint8_t tmp = inb(0x61) & 0xFC;

    outb(0x61, tmp);
}

////////////////////////////////////////////////////

extern void _start() {
    //outb(0x92, 2); ?
    
    idt_install();
    isrs_install();
    irq_install();
    __asm__ __volatile__ ("sti");

    timer_phase(100);
    irq_install_handler(0, timer_handler);
    irq_install_handler(1, keyboard_handler);

    graphics_rect((horizontal_head * 8) + 1, (vertical_head * 8) + 7, 6, 1, kernel_color);

    return;
}