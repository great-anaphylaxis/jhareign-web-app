#include "math.h"

char string_buffer[512];

char* string_itoa(int value, char * str, int base) {
    char * rc;
    char * ptr;
    char * low;
    // Check for supported base.
    if ( base < 2 || base > 36 )
    {
        *str = '\0';
        return str;
    }
    rc = ptr = str;
    // Set '-' for negative decimals.
    if ( value < 0 && base == 10 )
    {
        *ptr++ = '-';
    }
    // Remember where the numbers start.
    low = ptr;
    // The actual conversion.
    do
    {
        // Modulo is negative for negative value. This trick makes abs() unnecessary.
        *ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz"[35 + value % base];
        value /= base;
    } while ( value );
    // Terminating the string.
    *ptr-- = '\0';
    // Invert the numbers.
    while ( low < ptr )
    {
        char tmp = *low;
        *low++ = *ptr;
        *ptr-- = tmp;
    }
    return *str;
}

int string_atoi(char *str) {
    int retVal = 0;

    if (*str == '-') {
        str++;

        for (int i = 0; i < 9; i++) {
            if (*str == 0) {
                break;
            }
            else {
                retVal *= 10;
                retVal += (*str) - 48;
                str++;
            }
        }

        return retVal * -1;
    }

    else {
        for (int i = 0; i < 9; i++) {
            if (*str == 0) {
                break;
            }
            else {
                retVal *= 10;
                retVal += (*str) - 48;
                str++;
            }
        }

        return retVal;
    }
}

char* string_concat(char *str1, char *str2) {
    char l_str_buf[256];
    int fc = 0;
    int sc = 0;

    while (str1[fc] != 0) {
        l_str_buf[fc] = str1[fc];
        fc++;
    }

    while (str2[sc] != 0) {
        l_str_buf[fc + sc] = str2[sc];
        sc++;
    }

    l_str_buf[fc + sc] = 0;
    
    for (int i = 0; i < 256; i++) {
        string_buffer[i] = l_str_buf[i];
    }

    return string_buffer;
}

int string_compare(char *str1, char *str2) {
    while (*str1 != 0 && *str2 != 0) {
        if (*str1 == *str2) {
            str1 += 1;
            str2 += 1;
            
            continue;
        }
        else {
            return -1;
        }
    }
    
    if (*str1 == 0 && *str2 == 0) {
        return 1;
    }

    else {
        return -1;
    }
}