#include "math.h"

long rand_seed = 32321;

int math_min(int x, int y) {
    return x < y ? x : y;
}

int math_max(int x, int y) {
    return x > y ? x : y;
}

int math_clamp(int num, int x, int y) {
    return math_min(math_max(num, x), y);
}

int math_random(int min, int max) {
    rand_seed = rand_seed * 1103515245 + 12345;
    int raw = (unsigned int) (rand_seed / 65536) % 32768;

    return min + (int) (raw / (double) (32767 + 1) * (max - min + 1));
}