#ifndef GRAPHICS_H
#define GRAPHICS_H

void graphics_putPixel(int x, int y, char color);

void graphics_rect(int x, int y, int width, int height, char color);

void graphics_circle(int x, int y, int radius, char color);

void graphics_print_char(char c, int x, int y, char color);

void graphics_print_string(char* str, int x, int y, char color, int width, int height);

void graphics_clear_screen();

#endif