#ifndef KERNEL_H
#define KERNEL_H

static inline void outb(uint16_t port, uint8_t val) {
    asm volatile ( "outb %0, %1" : : "a"(val), "Nd"(port) );
}

static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    asm volatile ( "inb %1, %0": "=a"(ret): "Nd"(port) );
    return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

extern void (*application_OnKeyDown)(unsigned char scancode);
extern void (*application_OnKeyUp)(unsigned char scancode);
extern void (*application_Clean)();
extern void (*application_Update)();

void kernel_OnKeyDown(char scancode);

void kernel_OnKeyUp(char scancode);

void kernel_response(char *str);

void kernel_runCommand(char *str);

void kernel_exitApplication();

void kernel_commands_color(char params[3][40]);

void kernel_commands_run(char params[3][40]);

void kernel_commands_audio(char params[3][40]);

void kernel_command_help(char params[4][40]);

void play_sound(uint32_t nFrequence);

void play_sound_asNotes(char note, char pitch);

void stop_sound();

#endif