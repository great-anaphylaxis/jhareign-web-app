#include "../include/types.h"

#include "kernel.h"
#include "math.h"
#include "graphics.h"

int *mem_head = (int*)0x00100000;
int *mem_start = (int*)0x00100000;
int *mem_limit = (int*)0xBFFFF8000;

void* memset(void* dest, unsigned char val, int count){ 
	unsigned char* destC = (unsigned char*)dest;
	int i;
	for (i = 0; i < count; i++)
		destC[i] = val;
	return dest;
}

void memcp(unsigned char* source, unsigned char* dest, int count){
    for (int i = 0; i < count; i++)
        *(dest + i) = *(source + i);
}

void checkMemory() {
    if (mem_head >= mem_limit) {
        graphics_print_string("Memory reached it's limit!", 4, 0, 0, 40, 25);
        mem_head = mem_start;
        return;
    }

    if (*(char*)(mem_head) == 1) {
        mem_head += 5;
        checkMemory();
    }
    else {
        return;
    }
}

void* malloc() {
    void *retVal;

    *mem_head = (char) 1;
    retVal = (void*)(mem_head + 1);

    mem_head += 5;
    checkMemory();
    
    return retVal;
}

void mfree(void* ptr) {
    *(char*)(ptr - 1) = 0;
}